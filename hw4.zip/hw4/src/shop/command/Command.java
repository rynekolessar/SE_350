package shop.command;

// TODO: Write this class
public interface Command {

    public boolean run();

}
