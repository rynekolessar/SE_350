package shop.ui;

public interface UIMenuAction {
  public void run();
}
