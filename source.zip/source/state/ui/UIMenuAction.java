package state.ui;

public interface UIMenuAction {
  public Object run();
}
