package state.ui;

public class UIError extends Error {
}
