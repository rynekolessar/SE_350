package types.simplePackage;
public class Main {
  private Main() {}
  public static void main (String[] argv) {
    System.out.println("Hello Packages!");
  }
}
