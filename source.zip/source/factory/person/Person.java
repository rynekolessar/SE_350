package factory.person;
public interface Person extends Comparable {
  public String name();
  public SSN ssn();
}
