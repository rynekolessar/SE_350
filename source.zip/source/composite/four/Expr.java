package composite.four;
public interface Expr {
  int eval();
}
