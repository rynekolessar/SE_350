package composite.two;
public interface Expr {
  int eval();
}
