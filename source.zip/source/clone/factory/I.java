package clone.factory;
public interface I {}
