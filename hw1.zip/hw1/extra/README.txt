Please hand in build/hw1-src.zip.

This file will include:

  build.xml
  build.properties
  source (and all directories and .java files therein)
  extras (and all directories and files therein)

The extras directory is there for "extra" files.
You do not need to put anything there for this assignment.
