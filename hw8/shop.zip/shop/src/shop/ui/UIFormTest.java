package shop.ui;

public interface UIFormTest {
    public boolean run(String input);
}
